# Photoroom last top-up — 11 November 2026

Sixteen original sticker assets for Mat’s Photoroom library: speech and thought bubbles, wearable accessories, and simple cut-out props.

Made locally from original SVG, rasterised with cairosvg, and finished with a procedural muted pink-and-green marble. No stock photos, no sign-up services, no paid APIs, and no image generator.

This is a **standalone top-up pack**. It does **not** rebuild or replace `/workspace/PhotoroomLibrary.zip`. A previous sprint recovered zip-only entries into that archive (455 files / 471 zip entries at the time of this pack). Rebuilding the main zip in place would risk losing files, so it was left untouched.

## What’s in the pack

| File | Role |
| --- | --- |
| `png/` | 16 transparent PNGs, ready to drop into Photoroom |
| `svg/` | Editable original SVG for each sticker |
| `contact-sheet.png` | Checkerboard preview of all 16 |
| `src/build_assets.py` | Rebuild script |
| `asset-report.json` | Per-file size, pixels, transparency |
| `README.md` | This file |

**Names use the unique prefix `topup1111-`**, checked against every basename in the current library folder and in `PhotoroomLibrary.zip`. No collisions.

## Assets

| File | Kind | Pixels | Bytes | Transparent |
| --- | --- | --- | --- | --- |
| `topup1111-bubble-whisper-dashed-tail-down.png` | speech | 720×586 | 102,534 | 45.45% |
| `topup1111-bubble-wide-caption-bar.png` | speech | 720×195 | 53,434 | 24.31% |
| `topup1111-bubble-heart-speech-tail-left.png` | speech | 628×582 | 71,283 | 72.95% |
| `topup1111-bubble-chat-pill-left.png` | speech | 720×280 | 83,861 | 35.83% |
| `topup1111-bubble-thought-triple-dots.png` | speech | 696×688 | 64,920 | 65.96% |
| `topup1111-bubble-hex-speech-tail-right.png` | speech | 720×602 | 135,900 | 46.93% |
| `topup1111-wear-round-wire-glasses.png` | wearable | 720×256 | 85,915 | 84.17% |
| `topup1111-wear-cateye-glasses-clear.png` | wearable | 720×155 | 64,177 | 80.41% |
| `topup1111-wear-party-hat-cone-stripe.png` | wearable | 517×720 | 116,949 | 59.14% |
| `topup1111-wear-paper-crown-points.png` | wearable | 720×319 | 156,782 | 39.9% |
| `topup1111-wear-star-party-hat.png` | wearable | 481×720 | 174,344 | 61.91% |
| `topup1111-wear-leaf-laurel.png` | wearable | 720×252 | 59,916 | 88.91% |
| `topup1111-prop-blank-name-badge.png` | prop | 696×588 | 139,798 | 28.39% |
| `topup1111-prop-ribbon-banner.png` | prop | 720×251 | 103,227 | 37.97% |
| `topup1111-prop-polaroid-frame.png` | prop | 582×720 | 74,557 | 58.7% |
| `topup1111-prop-arrow-sign.png` | prop | 720×306 | 73,323 | 55.79% |

Bubble interiors are solid white so you can type on them. The polaroid photo well, glasses lenses, and the open centre of the laurel are transparent so a photo or a face can show through.

Wearables: round wire glasses, cat-eye glasses (clear lenses), striped party hat, paper crown, star party hat, leaf laurel.

Props: blank name badge, ribbon banner, polaroid frame, arrow sign.

## How to use

Import the PNGs in `png/` into Photoroom as stickers or elements. Print or crop as needed. The checkerboard contact sheet is only a preview.

Suggested library folders, if you later add these by hand:

- Speech / thought bubbles → `PHOTOROOM - transparent pngs/Speech bubbles/`
- Glasses, hats, crown, laurel → `PHOTOROOM - transparent pngs/OBJECTS - wearable objects/`
- Badge, banner, polaroid, arrow → `PHOTOROOM - transparent pngs/OBJECTS - objects for general things/`

## Rebuild

```bash
python3 src/build_assets.py
```

Needs Python 3, cairosvg, Pillow, and numpy. The script refuses to write a name that already exists in the main library.

## Checks (11 Nov 2026, Japan time)

- 16/16 names unique vs the main library zip and folder
- Main library zip was not modified (SHA-256 fingerprint recorded before this pack and verified after)
- Transparency, white interiors, and lens/photo-well holes were sampled on the rendered PNGs
- Edges inspected on a checkerboard contact sheet
- File sizes were not padded; marble detail means some stickers are above the ~50 KB aim

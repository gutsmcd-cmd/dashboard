#!/usr/bin/env python3
"""Original procedural Photoroom sticker pack. SVG -> PNG via cairosvg + local marble."""
from __future__ import annotations

import hashlib
import io
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import cairosvg

ROOT = Path(__file__).resolve().parents[1]
SVG_DIR = ROOT / "svg"
PNG_DIR = ROOT / "png"
SVG_DIR.mkdir(parents=True, exist_ok=True)
PNG_DIR.mkdir(parents=True, exist_ok=True)

# Magic fill replaced with marble after raster.
MARBLE = "#E01188"
WHITE = "#FFFFFF"
INK = "#2F3A36"
PINK = "#D4A0B0"
GREEN = "#7FA98C"

# Existing library basenames (filled by caller or loaded).
RESERVED: set[str] = set()


def marble_image(w: int, h: int, seed: int = 11) -> Image.Image:
    rng = np.random.RandomState(seed)
    y, x = np.ogrid[0:h, 0:w]
    x = x.astype(np.float32)
    y = y.astype(np.float32)

    def noise(scale: int, amp: float) -> np.ndarray:
        nw, nh = max(3, w // scale), max(3, h // scale)
        n = rng.rand(nh, nw)
        im = Image.fromarray((n * 255).astype(np.uint8), "L")
        im = im.resize((w, h), Image.Resampling.BICUBIC)
        return np.asarray(im, dtype=np.float32) / 255.0 * amp

    turb = noise(16, 1.0) + noise(8, 0.5) + noise(4, 0.25) + noise(2, 0.12)
    v = np.sin(x / 32.0 + y / 50.0 + turb * 5.5)
    v += 0.35 * np.sin(x / 11.0 - y / 18.0 + turb * 2.0)
    v = (v - v.min()) / (v.max() - v.min() + 1e-6)

    pink = np.array([212, 160, 176], dtype=np.float32)
    green = np.array([127, 169, 140], dtype=np.float32)
    cream = np.array([246, 238, 234], dtype=np.float32)
    # ridges toward cream, valleys toward green/pink
    t = v
    # mix pink and green with a slow diagonal
    blend = 0.5 + 0.5 * np.sin((x + y) / 90.0 + turb[:, :] * 1.4)
    base = pink[None, None, :] * (1 - blend)[..., None] + green[None, None, :] * blend[..., None]
    # highlight veins
    vein = np.clip((t - 0.55) * 2.2, 0, 1)[..., None]
    rgb = base * (1 - vein * 0.65) + cream[None, None, :] * (vein * 0.85 + 0.08)
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    return Image.fromarray(rgb, "RGB")


def svg_wrap(w: int, h: int, body: str, extras: str = "") -> str:
    return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">
  {extras}
  {body}
</svg>
'''


def render_svg(svg: str, w: int, h: int) -> Image.Image:
    data = cairosvg.svg2png(bytestring=svg.encode("utf-8"), output_width=w, output_height=h)
    return Image.open(io.BytesIO(data)).convert("RGBA")


def apply_marble(im: Image.Image, seed: int) -> Image.Image:
    """Replace near-MARBLE pixels with procedural marble, keep alpha."""
    arr = np.array(im)
    rgb = arr[..., :3].astype(np.int16)
    a = arr[..., 3]
    target = np.array([0xE0, 0x11, 0x88], dtype=np.int16)
    dist = np.abs(rgb - target).sum(axis=-1)
    # also catch anti-aliased edge mixes of marble with white or ink or transparent
    mask = (dist < 90) & (a > 8)
    if not mask.any():
        return im
    marble = np.asarray(marble_image(im.width, im.height, seed))
    out = arr.copy()
    # For partial alpha / antialias, shift hue toward marble but keep coverage
    out[mask, 0] = marble[mask, 0]
    out[mask, 1] = marble[mask, 1]
    out[mask, 2] = marble[mask, 2]
    return Image.fromarray(out, "RGBA")


def tight_crop(im: Image.Image, pad: int = 28) -> Image.Image:
    a = np.array(im.split()[-1])
    ys, xs = np.where(a > 8)
    if len(xs) == 0:
        return im
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    x0 = max(0, x0 - pad)
    y0 = max(0, y0 - pad)
    x1 = min(im.width, x1 + pad)
    y1 = min(im.height, y1 + pad)
    return im.crop((x0, y0, x1, y1))


def save_png(im: Image.Image, path: Path) -> None:
    # Reasonable compression, no palette if we need alpha
    im.save(path, format="PNG", optimize=True, compress_level=9)


# ----- shape helpers (SVG snippets) -----

def oval_path(cx, cy, rx, ry) -> str:
    # 4-curve ellipse
    return (
        f"M {cx-rx:.1f},{cy:.1f} "
        f"C {cx-rx:.1f},{cy-ry*0.552:.1f} {cx-rx*0.552:.1f},{cy-ry:.1f} {cx:.1f},{cy-ry:.1f} "
        f"C {cx+rx*0.552:.1f},{cy-ry:.1f} {cx+rx:.1f},{cy-ry*0.552:.1f} {cx+rx:.1f},{cy:.1f} "
        f"C {cx+rx:.1f},{cy+ry*0.552:.1f} {cx+rx*0.552:.1f},{cy+ry:.1f} {cx:.1f},{cy+ry:.1f} "
        f"C {cx-rx*0.552:.1f},{cy+ry:.1f} {cx-rx:.1f},{cy+ry*0.552:.1f} {cx-rx:.1f},{cy:.1f} Z"
    )


def heart_path(cx, cy, s) -> str:
    # classic heart centered near (cx, cy), size s
    return (
        f"M {cx:.1f},{cy+s*0.35:.1f} "
        f"C {cx-s*1.05:.1f},{cy-s*0.25:.1f} {cx-s*0.55:.1f},{cy-s*1.05:.1f} {cx:.1f},{cy-s*0.45:.1f} "
        f"C {cx+s*0.55:.1f},{cy-s*1.05:.1f} {cx+s*1.05:.1f},{cy-s*0.25:.1f} {cx:.1f},{cy+s*0.35:.1f} Z"
    )


def cloud_group(cx, cy, s, fill, stroke, sw) -> str:
    # union-like overlapping circles
    parts = [
        (cx - s * 0.55, cy + s * 0.05, s * 0.42),
        (cx + s * 0.55, cy + s * 0.08, s * 0.40),
        (cx - s * 0.15, cy - s * 0.28, s * 0.46),
        (cx + s * 0.28, cy - s * 0.18, s * 0.40),
        (cx, cy + s * 0.12, s * 0.50),
    ]
    # draw as one path of circles stacked (later circles on top). For a clean
    # outline we use a slightly larger marble underlayer + white inner circles.
    under = []
    inner = []
    grow = sw / 2
    for x, y, r in parts:
        under.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r+grow:.1f}" fill="{stroke}"/>')
        inner.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r-sw/2:.1f}" fill="{fill}"/>')
    # marble rim: a mid ring between stroke under and white — actually stroke is ink.
    # We'll put a marble ring by drawing a mid fill first.
    mid = []
    for x, y, r in parts:
        mid.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r+grow*0.35:.1f}" fill="{MARBLE}"/>')
    return "\n".join(under + mid + inner)


ASSETS = []  # filled below as (id, category, folder, w, h, svg_body, seed)


def register(aid, category, folder, w, h, body, seed=11, extras=""):
    ASSETS.append(dict(id=aid, category=category, folder=folder, w=w, h=h, body=body, seed=seed, extras=extras))


# 1 whisper dashed oval, tail down, white interior, marble dashed-look via outer ring
register(
    "topup1111-bubble-whisper-dashed-tail-down",
    "speech",
    "Speech bubbles",
    900, 700,
    f'''
    <g fill="none">
      <ellipse cx="450" cy="320" rx="330" ry="210" fill="{WHITE}" stroke="{INK}" stroke-width="10"/>
      <ellipse cx="450" cy="320" rx="330" ry="210" fill="none" stroke="{MARBLE}" stroke-width="22"
               stroke-dasharray="28 20" stroke-linecap="round"/>
      <!-- tail, dashed feel with solid tip -->
      <path d="M 400,520 L 430,640 L 500,515" fill="{WHITE}" stroke="{INK}" stroke-width="8" stroke-linejoin="round"/>
      <path d="M 408,528 L 430,620 L 488,522" fill="{WHITE}" stroke="none"/>
    </g>
    ''',
    seed=3,
)

# 2 wide caption bar
register(
    "topup1111-bubble-wide-caption-bar",
    "speech",
    "Speech bubbles",
    1100, 420,
    f'''
    <rect x="70" y="90" width="960" height="220" rx="40" ry="40" fill="{INK}"/>
    <rect x="82" y="102" width="936" height="196" rx="32" ry="32" fill="{MARBLE}"/>
    <rect x="108" y="122" width="884" height="156" rx="24" ry="24" fill="{WHITE}"/>
    ''',
    seed=17,
)

# 3 heart speech, tail left
register(
    "topup1111-bubble-heart-speech-tail-left",
    "speech",
    "Speech bubbles",
    820, 780,
    f'''
    <!-- tail first; base sits inside the lower-left lobe, heart drawn on top -->
    <path d="M 280,390 L 30,700 L 430,450" fill="{INK}"/>
    <path d="M 290,400 L 52,680 L 418,448" fill="{MARBLE}"/>
    <path d="M 305,412 L 80,655 L 405,446" fill="{WHITE}"/>
    <path d="{heart_path(430, 360, 280)}" fill="{INK}"/>
    <path d="{heart_path(430, 360, 262)}" fill="{MARBLE}"/>
    <path d="{heart_path(430, 358, 228)}" fill="{WHITE}"/>
    ''',
    seed=21,
)

# 4 chat pill left
register(
    "topup1111-bubble-chat-pill-left",
    "speech",
    "Speech bubbles",
    900, 560,
    f'''
    <path d="M 160,140 h 620 a 120,120 0 0 1 0,240 h -620 a 120,120 0 0 1 0,-240 z" fill="{INK}"/>
    <path d="M 170,150 h 600 a 110,110 0 0 1 0,220 h -600 a 110,110 0 0 1 0,-220 z" fill="{MARBLE}"/>
    <path d="M 192,172 h 556 a 88,88 0 0 1 0,176 h -556 a 88,88 0 0 1 0,-176 z" fill="{WHITE}"/>
    <!-- small left notch -->
    <path d="M 150,350 L 70,430 L 210,372" fill="{INK}"/>
    <path d="M 160,348 L 88,414 L 205,368" fill="{MARBLE}"/>
    <path d="M 168,350 L 108,400 L 200,366" fill="{WHITE}"/>
    ''',
    seed=8,
)

# 5 thought cloud + triple dots
register(
    "topup1111-bubble-thought-triple-dots",
    "speech",
    "Speech bubbles",
    900, 800,
    f'''
    {cloud_group(470, 300, 280, WHITE, INK, 16)}
    <!-- rising thought dots, white with marble ring -->
    <circle cx="230" cy="560" r="34" fill="{INK}"/>
    <circle cx="230" cy="560" r="28" fill="{MARBLE}"/>
    <circle cx="230" cy="560" r="16" fill="{WHITE}"/>
    <circle cx="170" cy="640" r="24" fill="{INK}"/>
    <circle cx="170" cy="640" r="19" fill="{MARBLE}"/>
    <circle cx="170" cy="640" r="11" fill="{WHITE}"/>
    <circle cx="120" cy="700" r="16" fill="{INK}"/>
    <circle cx="120" cy="700" r="12" fill="{MARBLE}"/>
    <circle cx="120" cy="700" r="6" fill="{WHITE}"/>
    ''',
    seed=29,
)

# 6 hex speech, tail right
register(
    "topup1111-bubble-hex-speech-tail-right",
    "speech",
    "Speech bubbles",
    900, 760,
    f'''
    <polygon points="450,80 730,220 730,500 450,640 170,500 170,220" fill="{INK}"/>
    <polygon points="450,96 714,228 714,492 450,624 186,492 186,228" fill="{MARBLE}"/>
    <polygon points="450,128 682,248 682,472 450,592 218,472 218,248" fill="{WHITE}"/>
    <path d="M 700,470 L 850,560 L 680,530" fill="{INK}"/>
    <path d="M 705,478 L 828,548 L 678,524" fill="{MARBLE}"/>
    <path d="M 700,486 L 800,536 L 678,518" fill="{WHITE}"/>
    ''',
    seed=12,
)

# 7 round wire glasses — lenses fully transparent, marble rims
register(
    "topup1111-wear-round-wire-glasses",
    "wearable",
    "OBJECTS - wearable objects",
    1000, 420,
    f'''
    <!-- temples -->
    <path d="M 148,200 L 20,170" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 852,200 L 980,170" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 148,200 L 20,170" fill="none" stroke="{MARBLE}" stroke-width="8" stroke-linecap="round"/>
    <path d="M 852,200 L 980,170" fill="none" stroke="{MARBLE}" stroke-width="8" stroke-linecap="round"/>
    <!-- rims (rings only, evenodd holes = transparent lenses) -->
    <path fill="{INK}" fill-rule="evenodd"
          d="M 190,200 a 150,150 0 1 0 300,0 a 150,150 0 1 0 -300,0 M 214,200 a 126,126 0 1 0 252,0 a 126,126 0 1 0 -252,0"/>
    <path fill="{MARBLE}" fill-rule="evenodd"
          d="M 198,200 a 142,142 0 1 0 284,0 a 142,142 0 1 0 -284,0 M 218,200 a 122,122 0 1 0 244,0 a 122,122 0 1 0 -244,0"/>
    <path fill="{INK}" fill-rule="evenodd"
          d="M 510,200 a 150,150 0 1 0 300,0 a 150,150 0 1 0 -300,0 M 534,200 a 126,126 0 1 0 252,0 a 126,126 0 1 0 -252,0"/>
    <path fill="{MARBLE}" fill-rule="evenodd"
          d="M 518,200 a 142,142 0 1 0 284,0 a 142,142 0 1 0 -284,0 M 538,200 a 122,122 0 1 0 244,0 a 122,122 0 1 0 -244,0"/>
    <!-- bridge -->
    <path d="M 490,200 C 510,168 490,168 510,200" fill="none" stroke="{INK}" stroke-width="14" stroke-linecap="round"/>
    <path d="M 490,200 C 510,168 490,168 510,200" fill="none" stroke="{MARBLE}" stroke-width="7" stroke-linecap="round"/>
    ''',
    seed=5,
)

# 8 cat-eye glasses, clear lenses
register(
    "topup1111-wear-cateye-glasses-clear",
    "wearable",
    "OBJECTS - wearable objects",
    1000, 420,
    f'''
    <path d="M 130,210 L 18,185" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 870,210 L 982,185" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 130,210 L 18,185" fill="none" stroke="{MARBLE}" stroke-width="8" stroke-linecap="round"/>
    <path d="M 870,210 L 982,185" fill="none" stroke="{MARBLE}" stroke-width="8" stroke-linecap="round"/>
    <!-- left cat-eye: pointed outer corner -->
    <path fill="{INK}" fill-rule="evenodd" d="
      M 150,210
      C 150,130 250,110 340,140
      C 410,162 430,200 400,245
      C 360,300 200,300 160,240
      C 145,225 145,218 150,210 Z
      M 175,210
      C 180,155 255,145 325,165
      C 375,182 392,210 370,240
      C 340,280 215,280 185,235
      C 172,222 172,216 175,210 Z"/>
    <path fill="{MARBLE}" fill-rule="evenodd" d="
      M 156,210
      C 158,138 250,118 338,146
      C 402,166 420,200 394,242
      C 356,292 204,292 166,238
      C 152,224 152,216 156,210 Z
      M 178,210
      C 182,158 255,148 322,167
      C 370,184 386,210 366,238
      C 338,276 218,276 188,233
      C 176,222 176,216 178,210 Z"/>
    <!-- right cat-eye (mirror) -->
    <path fill="{INK}" fill-rule="evenodd" d="
      M 850,210
      C 850,130 750,110 660,140
      C 590,162 570,200 600,245
      C 640,300 800,300 840,240
      C 855,225 855,218 850,210 Z
      M 825,210
      C 820,155 745,145 675,165
      C 625,182 608,210 630,240
      C 660,280 785,280 815,235
      C 828,222 828,216 825,210 Z"/>
    <path fill="{MARBLE}" fill-rule="evenodd" d="
      M 844,210
      C 842,138 750,118 662,146
      C 598,166 580,200 606,242
      C 644,292 796,292 834,238
      C 848,224 848,216 844,210 Z
      M 822,210
      C 818,158 745,148 678,167
      C 630,184 614,210 634,238
      C 662,276 782,276 812,233
      C 824,222 824,216 822,210 Z"/>
    <path d="M 430,210 C 470,178 530,178 570,210" fill="none" stroke="{INK}" stroke-width="14" stroke-linecap="round"/>
    <path d="M 430,210 C 470,178 530,178 570,210" fill="none" stroke="{MARBLE}" stroke-width="7" stroke-linecap="round"/>
    ''',
    seed=19,
)

# 9 party hat cone with muted pink/green stripes + marble brim/pom
register(
    "topup1111-wear-party-hat-cone-stripe",
    "wearable",
    "OBJECTS - wearable objects",
    640, 860,
    f'''
    <!-- cone body clipped stripes -->
    <defs>
      <clipPath id="cone"><polygon points="320,80 80,700 560,700"/></clipPath>
    </defs>
    <polygon points="320,80 80,700 560,700" fill="{INK}"/>
    <polygon points="320,96 100,688 540,688" fill="{PINK}"/>
    <g clip-path="url(#cone)">
      <g transform="rotate(-18 320 400)">
        <rect x="-40" y="80" width="80" height="700" fill="{GREEN}"/>
        <rect x="120" y="80" width="80" height="700" fill="{GREEN}"/>
        <rect x="280" y="80" width="80" height="700" fill="{GREEN}"/>
        <rect x="440" y="80" width="80" height="700" fill="{GREEN}"/>
        <rect x="600" y="80" width="80" height="700" fill="{GREEN}"/>
      </g>
    </g>
    <!-- brim -->
    <ellipse cx="320" cy="700" rx="250" ry="48" fill="{INK}"/>
    <ellipse cx="320" cy="696" rx="236" ry="38" fill="{MARBLE}"/>
    <!-- pom pom -->
    <circle cx="320" cy="78" r="48" fill="{INK}"/>
    <circle cx="320" cy="78" r="40" fill="{MARBLE}"/>
    ''',
    seed=7,
)

# 10 paper crown (birthday, not jeweled)
register(
    "topup1111-wear-paper-crown-points",
    "wearable",
    "OBJECTS - wearable objects",
    980, 520,
    f'''
    <!-- band + five points -->
    <path d="M 60,420 L 60,250 L 160,80 L 280,250 L 400,70 L 520,250 L 640,70 L 760,250 L 880,80 L 920,250 L 920,420 Z"
          fill="{INK}"/>
    <path d="M 76,408 L 76,250 L 160,104 L 272,250 L 400,96 L 528,250 L 640,96 L 768,250 L 860,104 L 904,250 L 904,408 Z"
          fill="{MARBLE}"/>
    <!-- inner paper band (slightly lighter cut so it reads as a wearable crown opening at the bottom) -->
    <path d="M 110,408 L 110,300 L 870,300 L 870,408 Z" fill="{PINK}"/>
    <path d="M 110,408 L 110,336 L 870,336 L 870,408 Z" fill="{GREEN}"/>
    ''',
    seed=14,
)

# 11 star-topped party hat
register(
    "topup1111-wear-star-party-hat",
    "wearable",
    "OBJECTS - wearable objects",
    640, 900,
    f'''
    <defs>
      <clipPath id="cone2"><polygon points="320,160 90,740 550,740"/></clipPath>
    </defs>
    <polygon points="320,160 90,740 550,740" fill="{INK}"/>
    <polygon points="320,174 108,728 532,728" fill="{MARBLE}"/>
    <g clip-path="url(#cone2)">
      <g transform="rotate(16 320 480)">
        <rect x="-20" y="140" width="70" height="720" fill="{PINK}"/>
        <rect x="150" y="140" width="70" height="720" fill="{PINK}"/>
        <rect x="320" y="140" width="70" height="720" fill="{PINK}"/>
        <rect x="490" y="140" width="70" height="720" fill="{PINK}"/>
        <rect x="660" y="140" width="70" height="720" fill="{PINK}"/>
      </g>
    </g>
    <ellipse cx="320" cy="742" rx="245" ry="46" fill="{INK}"/>
    <ellipse cx="320" cy="738" rx="230" ry="36" fill="{GREEN}"/>
    <!-- star -->
    <polygon points="320,20 348,96 430,96 364,144 388,228 320,178 252,228 276,144 210,96 292,96"
             fill="{INK}"/>
    <polygon points="320,36 344,100 414,100 358,140 378,212 320,170 262,212 282,140 226,100 296,100"
             fill="{MARBLE}"/>
    ''',
    seed=23,
)

# 12 leaf laurel (open at top, sits on a head)
register(
    "topup1111-wear-leaf-laurel",
    "wearable",
    "OBJECTS - wearable objects",
    980, 520,
    f'''
    <!-- two arched branches, open at the top -->
    <path d="M 490,400 C 300,400 160,300 110,180" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 490,400 C 680,400 820,300 870,180" fill="none" stroke="{INK}" stroke-width="16" stroke-linecap="round"/>
    <path d="M 490,400 C 300,400 160,300 110,180" fill="none" stroke="{GREEN}" stroke-width="8" stroke-linecap="round"/>
    <path d="M 490,400 C 680,400 820,300 870,180" fill="none" stroke="{GREEN}" stroke-width="8" stroke-linecap="round"/>
    '''
    + "".join(
        # leaves along each branch
        f'''<ellipse cx="{x}" cy="{y}" rx="28" ry="14" transform="rotate({ang} {x} {y})" fill="{INK}"/>
            <ellipse cx="{x}" cy="{y}" rx="22" ry="10" transform="rotate({ang} {x} {y})" fill="{MARBLE}"/>'''
        for x, y, ang in [
            (160, 210, -55), (200, 270, -40), (250, 320, -30), (310, 355, -18), (380, 378, -8),
            (820, 210, 55), (780, 270, 40), (730, 320, 30), (670, 355, 18), (600, 378, 8),
            (150, 250, -70), (830, 250, 70),
        ]
    ),
    seed=31,
)

# 13 blank name badge — white center for text, marble ring
register(
    "topup1111-prop-blank-name-badge",
    "prop",
    "OBJECTS - objects for general things",
    820, 640,
    f'''
    <!-- pin -->
    <rect x="390" y="40" width="40" height="70" rx="6" fill="{INK}"/>
    <rect x="396" y="46" width="28" height="58" rx="4" fill="{MARBLE}"/>
    <circle cx="410" cy="48" r="22" fill="{INK}"/>
    <circle cx="410" cy="48" r="16" fill="{MARBLE}"/>
    <!-- badge body -->
    <rect x="90" y="100" width="640" height="460" rx="70" ry="70" fill="{INK}"/>
    <rect x="106" y="116" width="608" height="428" rx="58" ry="58" fill="{MARBLE}"/>
    <rect x="150" y="160" width="520" height="340" rx="40" ry="40" fill="{WHITE}"/>
    ''',
    seed=9,
)

# 14 ribbon banner, white writing area
register(
    "topup1111-prop-ribbon-banner",
    "prop",
    "OBJECTS - objects for general things",
    1100, 520,
    f'''
    <!-- tails -->
    <path d="M 140,140 L 40,80 L 40,400 L 140,340 Z" fill="{INK}"/>
    <path d="M 960,140 L 1060,80 L 1060,400 L 960,340 Z" fill="{INK}"/>
    <path d="M 140,150 L 56,100 L 56,380 L 140,330 Z" fill="{MARBLE}"/>
    <path d="M 960,150 L 1044,100 L 1044,380 L 960,330 Z" fill="{MARBLE}"/>
    <!-- center ribbon -->
    <path d="M 140,120 H 960 V 360 H 140 Z" fill="{INK}"/>
    <path d="M 150,132 H 950 V 348 H 150 Z" fill="{MARBLE}"/>
    <path d="M 190,162 H 910 V 318 H 190 Z" fill="{WHITE}"/>
    <!-- folds -->
    <path d="M 140,120 L 180,160 L 140,200 Z" fill="{GREEN}"/>
    <path d="M 960,120 L 920,160 L 960,200 Z" fill="{GREEN}"/>
    <path d="M 140,280 L 180,320 L 140,360 Z" fill="{GREEN}"/>
    <path d="M 960,280 L 920,320 L 960,360 Z" fill="{GREEN}"/>
    ''',
    seed=16,
)

# 15 polaroid frame — transparent photo well
register(
    "topup1111-prop-polaroid-frame",
    "prop",
    "OBJECTS - objects for general things",
    720, 860,
    f'''
    <rect x="50" y="40" width="620" height="780" rx="18" fill="{INK}"/>
    <rect x="62" y="52" width="596" height="756" rx="12" fill="{MARBLE}"/>
    <rect x="88" y="78" width="544" height="200" rx="4" fill="{WHITE}"/>
    <!-- lower white border (classic polaroid chin) -->
    <rect x="88" y="620" width="544" height="164" fill="{WHITE}"/>
    <!-- photo well is a HOLE: cut from marble by evenodd on a covering white? 
         We punch transparency by not filling the well — draw frame as evenodd. -->
    <!-- overwrite the well region as fully empty: use evenodd on the main body -->
    ''',
    seed=4,
)

# Polaroid needs a real hole. Rebuild that asset more carefully below after the list.

# 16 arrow sign, white interior
register(
    "topup1111-prop-arrow-sign",
    "prop",
    "OBJECTS - objects for general things",
    1040, 520,
    f'''
    <path d="M 60,160 H 680 L 680,80 L 980,260 L 680,440 L 680,360 H 60 Z" fill="{INK}"/>
    <path d="M 78,176 H 690 L 690,108 L 948,260 L 690,412 L 690,344 H 78 Z" fill="{MARBLE}"/>
    <path d="M 110,200 H 690 L 690,150 L 880,260 L 690,370 L 690,320 H 110 Z" fill="{WHITE}"/>
    ''',
    seed=27,
)


def rebuild_polaroid():
    # replace the polaroid entry with a proper evenodd hole
    for a in ASSETS:
        if a["id"] == "topup1111-prop-polaroid-frame":
            a["body"] = f'''
            <!-- outer frame marble, classic deep white chin, transparent photo well -->
            <path fill="{INK}" fill-rule="evenodd" d="
              M 50,40 h 620 v 780 h -620 z
              M 108,92 h 504 v 500 h -504 z"/>
            <path fill="{MARBLE}" fill-rule="evenodd" d="
              M 62,52 h 596 v 756 h -596 z
              M 108,92 h 504 v 500 h -504 z"/>
            <!-- solid white chin and thin top/side mat around the hole -->
            <path fill="{WHITE}" fill-rule="evenodd" d="
              M 80,70 h 560 v 720 h -560 z
              M 108,92 h 504 v 500 h -504 z"/>
            '''
            break


rebuild_polaroid()


def load_reserved() -> set[str]:
    names = set()
    zpath = Path("/workspace/PhotoroomLibrary.zip")
    if zpath.exists():
        import zipfile
        with zipfile.ZipFile(zpath) as z:
            for n in z.namelist():
                names.add(Path(n).name.lower())
    folder = Path("/workspace/PhotoroomLibrary")
    if folder.exists():
        for p in folder.rglob("*"):
            if p.is_file():
                names.add(p.name.lower())
    return names


def checker(w, h, cell=16):
    im = Image.new("RGB", (w, h), (235, 235, 235))
    d = ImageDraw.Draw(im)
    for y in range(0, h, cell):
        for x in range(0, w, cell):
            if (x // cell + y // cell) % 2 == 0:
                d.rectangle([x, y, x + cell - 1, y + cell - 1], fill=(210, 210, 210))
    return im


def analyze(im: Image.Image, aid: str) -> dict:
    arr = np.array(im)
    a = arr[..., 3]
    total = a.size
    opaque = int((a >= 250).sum())
    trans = int((a <= 8).sum())
    fringe = int(((a > 8) & (a < 250)).sum())
    info = {
        "id": aid,
        "size_px": [im.width, im.height],
        "mode": im.mode,
        "opaque_pct": round(100 * opaque / total, 2),
        "transparent_pct": round(100 * trans / total, 2),
        "fringe_pct": round(100 * fringe / total, 2),
        "has_transparency": trans > 0,
    }
    # interior probe for bubbles / badge / banner / arrow: center should be white or clear
    cx, cy = im.width // 2, int(im.height * 0.42)
    # clamp
    cx = min(max(cx, 0), im.width - 1)
    cy = min(max(cy, 0), im.height - 1)
    px = tuple(int(v) for v in arr[cy, cx])
    info["center_rgba"] = px
    return info


def build():
    reserved = load_reserved()
    collisions = [a["id"] + ".png" for a in ASSETS if (a["id"] + ".png").lower() in reserved
                  or (a["id"] + ".svg").lower() in reserved]
    if collisions:
        raise SystemExit(f"Name collisions with existing library: {collisions}")

    reports = []
    for a in ASSETS:
        svg = svg_wrap(a["w"], a["h"], a["body"], a.get("extras", ""))
        svg_path = SVG_DIR / f"{a['id']}.svg"
        svg_path.write_text(svg, encoding="utf-8")
        im = render_svg(svg, a["w"], a["h"])
        im = apply_marble(im, a["seed"])
        im = tight_crop(im, pad=28)
        max_side = 720
        if max(im.size) > max_side:
            s = max_side / max(im.size)
            im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.Resampling.LANCZOS)
        png_path = PNG_DIR / f"{a['id']}.png"
        save_png(im, png_path)
        st = png_path.stat().st_size
        info = analyze(im, a["id"])
        info.update(category=a["category"], folder=a["folder"], bytes=st, svg=str(svg_path.name), png=str(png_path.name))
        reports.append(info)
        print(f"{a['id']}: {im.width}x{im.height}  {st} bytes  trans={info['transparent_pct']}%  center={info['center_rgba']}")

    # contact sheet
    n = len(reports)
    cols = 4
    rows = math.ceil(n / cols)
    thumb = 280
    pad = 16
    label_h = 36
    title_h = 56
    sheet_w = pad + cols * (thumb + pad)
    sheet_h = title_h + rows * (thumb + label_h + pad) + pad
    sheet = Image.new("RGB", (sheet_w, sheet_h), (250, 250, 250))
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 22)
        font_s = ImageFont.truetype("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 13)
    except Exception:
        font = ImageFont.load_default()
        font_s = font
    title = "Photoroom last top-up  ·  16 original stickers  ·  11 Nov 2026"
    bbox = draw.textbbox((0, 0), title, font=font)
    draw.text(((sheet_w - (bbox[2] - bbox[0])) / 2, 16), title, fill=(30, 40, 36), font=font)

    for i, (a, info) in enumerate(zip(ASSETS, reports)):
        col, row = i % cols, i // cols
        x = pad + col * (thumb + pad)
        y = title_h + row * (thumb + label_h + pad)
        bg = checker(thumb, thumb, 14)
        im = Image.open(PNG_DIR / a["id"]).convert("RGBA") if False else Image.open(PNG_DIR / f"{a['id']}.png").convert("RGBA")
        # fit
        scale = min((thumb - 16) / im.width, (thumb - 16) / im.height)
        nw, nh = max(1, int(im.width * scale)), max(1, int(im.height * scale))
        th = im.resize((nw, nh), Image.Resampling.LANCZOS)
        bg.paste(th, ((thumb - nw) // 2, (thumb - nh) // 2), th)
        sheet.paste(bg, (x, y))
        draw.rectangle([x, y, x + thumb - 1, y + thumb - 1], outline=(40, 50, 46), width=2)
        label = a["id"].replace("topup1111-", "")
        draw.text((x, y + thumb + 6), label, fill=(30, 40, 36), font=font_s)

    contact = ROOT / "contact-sheet.png"
    sheet.save(contact, format="PNG", optimize=True, compress_level=9)

    (ROOT / "asset-report.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
    return reports, contact


if __name__ == "__main__":
    reports, contact = build()
    print(f"built {len(reports)} assets; contact {contact}")

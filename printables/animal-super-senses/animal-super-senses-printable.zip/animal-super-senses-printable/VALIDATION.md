# Validation summary — Animal Super Senses printable

Checked 11 November 2026, Japan time (UTC+9).

## File

- PDF: `animal-super-senses.pdf`
- Pages: 5
- Page size: 595.276 × 841.89 pt (A4 portrait)
- PDF version: 1.4, unencrypted
- Built with local ReportLab 5.0.1 from `data/cards.json` and `src/build.py`
- Font: Liberation Sans (regular, bold, italic)

## Layout checks

- The builder wraps text and exits with an error if a clue or answer would overflow its box. The final build reported **no overflow**.
- Pages were rendered with `pdftoppm` at 150 dpi (1241 × 1754 px) and inspected visually.
- No clipped or overflowing text on any page. All 12 “What animal am I?” prompts are fully visible. All 12 answers and short facts on page 5 are complete.
- Clue body text is 12 pt, which stays comfortably inside every card, including the longest card (dog, card 9).
- Cut guides are dashed lines between the four cards on pages 2–4, with small line-art cut marks. The answer page has no cut guides.

## Margins and print safety

Content bounding box, including the outer double border and the footer (which sits inside the border):

| Page | Left | Right | Top | Bottom |
| --- | --- | --- | --- | --- |
| 1 Cover | 12.2 mm | 12.4 mm | 12.2 mm | 12.2 mm |
| 2 Cards 1–4 | 12.2 mm | 12.4 mm | 12.2 mm | 12.2 mm |
| 3 Cards 5–8 | 12.2 mm | 12.4 mm | 12.2 mm | 12.2 mm |
| 4 Cards 9–12 | 12.2 mm | 12.4 mm | 12.2 mm | 12.2 mm |
| 5 Answers | 12.2 mm | 12.4 mm | 12.2 mm | 12.2 mm |

All sides are at least 12 mm from the physical page edge, which should be safe for a Phomemo / Itari M08F thermal printer if printed at 100% / actual size.

## Colour

- The builder uses only black and white. There are no grey fills, no photographs, and no generated art. Cover icons are simple line drawings (eye, ear, bolt, sound waves).
- Rendered PNGs show about 2.5–4.8% mid-tone pixels, which is anti-aliasing on text and lines, not grey fills in the PDF.
- Black ink coverage is about 7.5–8.4% of each page (thermal-friendly; no large solid black panels except two thin title bars on the cover).

## Content completeness

`pdftotext` confirms:

- Cover instructions (eight steps), printing tip, and science note are present.
- Pages 2–4 contain clue cards 1 through 12, each with Clue 1, Clue 2, Clue 3, and “What animal am I?”
- Page 5 contains all 12 answers: Bat, Shark, Pit viper, Owl, Dolphin, Honey bee, Star-nosed mole, Migratory bird, Dog, Elephant, Bald eagle, Platypus.

## Science notes (for the record)

Facts were checked against the free public sources listed in `README.md`. Wording is conservative:

- Birds: the pack says they can detect Earth’s magnetic field and use it like a compass. It does not claim they “see” the field.
- Elephants: “several kilometres,” not a single record distance.
- Bald eagle vision: the U.S. Fish and Wildlife Service “almost a mile” figure, not larger popular claims.
- Dog receptor counts: given as a commonly cited figure, with a note that the number varies by breed.

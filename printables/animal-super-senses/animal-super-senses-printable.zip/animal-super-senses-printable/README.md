# Animal Super Senses

A 12-card science guessing game about unusual animal senses. Made as an A4, black-and-white printable for class or family play, including a Phomemo or Itari M08F thermal printer.

This pack is a **printable**, not an app. It is separate from the Animal Senses Explorer app and does not replace or overwrite it.

Facts were checked on 11 November 2026 (Japan time) against the free public sources listed below. Clues stay with well-established findings. Popular claims that are still unsettled (for example, that birds literally “see” magnetic fields) are left out.

## What’s in this folder

| File | What it is |
| --- | --- |
| `animal-super-senses.pdf` | The printable (5 A4 portrait pages) |
| `data/cards.json` | Editable card text, answers, and source links |
| `src/build.py` | Rebuilds the PDF with ReportLab |
| `previews/` | PNG previews of each page, plus a contact sheet |
| `README.md` | This file |

The ZIP contains the same files.

**Page guide**

1. Title and how to play
2. Clue cards 1–4 (bat, shark, pit viper, owl)
3. Clue cards 5–8 (dolphin, honey bee, star-nosed mole, migratory bird)
4. Clue cards 9–12 (dog, elephant, bald eagle, platypus)
5. Answer page — keep this one uncut

## How to print

- Paper size: **A4 portrait**
- Colour: **black only**, white background
- Scale: **actual size / 100%**. Do not “fit to page,” which can shrink the safe margins.
- The layout uses strong black lines and no grey fills, so it should print cleanly on a Phomemo or Itari M08F thermal printer, or on a mono laser or inkjet.
- Leave the margins as they are (about 15 mm). Cut the clue cards along the dashed lines after printing.

## How to play

One person is the reader and keeps the answer page. Everyone else guesses.

1. Shuffle the 12 clue cards.
2. The reader picks a card and reads **Clue 1** aloud. Anyone may guess. If nobody is right, read Clue 2, then Clue 3.
3. Optional scoring: 3 points after Clue 1, 2 points after Clue 2, 1 point after Clue 3.
4. Wrong guesses are fine. Keep going, or agree that a wrong guess means you wait for the next clue.
5. After all 12 cards, the highest score wins — or skip the points and just play.

Solo play: read the clues, write a guess, then check the answer page.

About ages 8 and up. Younger players can join if someone reads the clues aloud.

**Close answers.** “Eagle” is fine for the bald eagle. “Bee” is fine for the honey bee. “Toothed whale” or “porpoise” is fair for the dolphin. “Ray” is close for the shark (they share the electric sense) but the card is written for a shark. For the pit viper, star-nosed mole, and migratory bird, a bare “snake,” “mole,” or “bird” is only half credit unless the player also names the special sense or a more precise animal.

## How to rebuild

From this folder, on a machine with Python 3, ReportLab, and Liberation Sans installed:

```bash
python3 src/build.py
```

The script writes `animal-super-senses.pdf` and exits with an error if text would overflow a card or answer box. After changing `data/cards.json`, run it again.

## Sources

Each fact below is the claim used in the clues or on the answer page, with the public page it was checked against.

1. **Bat — echolocation.** Many bats send out ultrasound and listen to the returning echoes. Bats are not blind; many see well in dim light.  
   Smithsonian Magazine, “Five Amazing Adaptations That Help Animals Thrive in the Dark”: https://www.smithsonianmag.com/science-nature/five-amazing-adaptations-that-help-animals-thrive-in-the-dark-180979612/

2. **Shark — electroreception.** Sharks (and rays) have jelly-filled pores called the ampullae of Lorenzini that detect weak electric fields from living animals. Sharks also feel water movement with a lateral line.  
   Smithsonian Magazine, “Sense and Sensitivity”: https://www.smithsonianmag.com/science-nature/sense-and-sensitivity-48346717/

3. **Pit viper — heat sensing.** Pit vipers have heat-sensitive pits between the eyes and nostrils. Those pits can detect a warm animal up to about a metre (about three feet) away. Some pythons and boas have heat sensors too.  
   Same Smithsonian article as card 1: https://www.smithsonianmag.com/science-nature/five-amazing-adaptations-that-help-animals-thrive-in-the-dark-180979612/

4. **Owl — directional hearing.** In many owl species, one ear sits higher than the other, so a sound reaches each ear at a slightly different time and loudness. That helps the owl locate prey in darkness.  
   American Museum of Natural History, “What’s This? Sensing”: https://www.amnh.org/explore/ology/zoology/whats-this-sensing

5. **Dolphin — echolocation.** Dolphins and other toothed whales use clicks and echoes to find prey and to navigate, including in murky water.  
   Same AMNH page as card 4: https://www.amnh.org/explore/ology/zoology/whats-this-sensing

6. **Honey bee — ultraviolet vision.** Bees can detect ultraviolet light. Many flowers have ultraviolet “nectar guides,” patterns people cannot see, that point toward the centre of the flower.  
   U.S. Forest Service, “Bee Pollination”: https://www.fs.usda.gov/wildflowers/pollinators/animals/bees.shtml  
   Smithsonian Gardens, Pollinator Garden: https://gardens.si.edu/gardens/pollinator-garden/

7. **Star-nosed mole — touch.** The star has 22 fleshy rays around the nostrils, covered with about 25,000 touch organs called Eimer’s organs. The mole can identify small prey in a fraction of a second.  
   American Museum of Natural History, “Star-Nosed Mole: World’s Most Sophisticated Sniffer”: https://www.amnh.org/explore/news-blogs/star-nosed-mole-scent  
   Vanderbilt University, Catania Lab, star-nosed mole page (about 25,000 touch organs): https://as.vanderbilt.edu/catanialab/research/star-nosed-mole/

8. **Migratory bird — magnetoreception.** Many migratory birds can detect Earth’s magnetic field and use it like a compass. In classic tests, European robins changed direction when the field around them was rotated. How the sense works is still being studied, so this pack does not claim that birds “see” the field.  
   Audubon Magazine, “Star Trek: How Birds Use Electromagnetic Cues to Travel”: https://www.audubon.org/magazine/star-trek-how-birds-use-electromagnetic-cues-travel

9. **Dog — smell.** Dogs have far more scent receptors than people. A figure often given is about 300 million, versus about 6 million in humans; the number varies by breed. Dogs can also sample air separately with each nostril.  
   PBS NOVA, “How Dogs’ Noses Know So Much”: https://www.pbs.org/wgbh/nova/article/dogs-sense-of-smell/  
   Craven, Paterson and Settles, 2010, *Journal of the Royal Society Interface*: https://pmc.ncbi.nlm.nih.gov/articles/PMC2871809/

10. **Elephant — infrasound.** Elephants make deep rumbles, including sounds too low for people to hear well. These calls can travel several kilometres and help family groups stay in touch. Range depends on the habitat and the weather. Playback work on East African savannas found responses at about 2 kilometres, and researchers estimated that a full-volume call could be detected about 4 kilometres away. This pack uses the conservative wording “several kilometres,” not a single record distance.  
    Cornell Center for Conservation Bioacoustics, Elephant Listening Project, “Elephant Sound”: https://www.birds.cornell.edu/ccb/elephant-sound/

11. **Bald eagle — sharp vision.** Bald eagles have very sharp daytime vision. A U.S. Fish and Wildlife Service fact sheet says a bald eagle can spot a moving rabbit almost a mile (about 1.6 kilometres) away. Larger popular figures were not used.  
    U.S. Fish and Wildlife Service, “Ten Facts About Bald Eagles”: https://www.fws.gov/sites/default/files/documents/2024-04/1917.pdf

12. **Platypus — electroreception.** When a platypus dives, it closes its eyes, ears, and nostrils. Its bill holds tens of thousands of electroreceptors (about 40,000 are often cited) plus touch sensors, which pick up tiny electric signals from prey in the water.  
    American Museum of Natural History, “Platypus Hunts Using Electric Sixth Sense”: https://www.amnh.org/explore/news-blogs/platypus-electroreception-hunting

## Notes

- This is a classroom and family science game, not medical advice, and not a claim about human health or hidden human senses.
- Simple geometric icons on the cover (eye, ear, bolt, sound waves) are line drawings, not pictures of animals.
- British spelling is used (centre, metre, kilometre) to match earlier classroom printables.

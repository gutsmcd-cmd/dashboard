#!/usr/bin/env python3
"""Build the Animal Super Senses A4 black-and-white printable PDF."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from reportlab.lib.colors import black, white
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "cards.json"
OUT_PDF = ROOT / "animal-super-senses.pdf"

FONT_DIR = Path("/usr/share/fonts/truetype/liberation")
pdfmetrics.registerFont(TTFont("Sans", str(FONT_DIR / "LiberationSans-Regular.ttf")))
pdfmetrics.registerFont(TTFont("Sans-Bold", str(FONT_DIR / "LiberationSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("Sans-Italic", str(FONT_DIR / "LiberationSans-Italic.ttf")))
pdfmetrics.registerFont(TTFont("Sans-BoldItalic", str(FONT_DIR / "LiberationSans-BoldItalic.ttf")))

PAGE_W, PAGE_H = A4  # 595.27 x 841.89 pt
# ~15 mm outer margin: safer for Phomemo / Itari M08F thermal feed and grip.
MARGIN = 42
# Keep drawn content this far from the physical page edge.
SAFE = 36

ISSUES: list[str] = []


def record(msg: str) -> None:
    ISSUES.append(msg)
    print("LAYOUT:", msg, file=sys.stderr)


def wrap_lines(text: str, font: str, size: float, width: float) -> list[str]:
    """Word-wrap text. Long tokens are character-split so nothing overflows."""
    words = text.split()
    lines: list[str] = []
    line = ""
    for word in words:
        trial = word if not line else f"{line} {word}"
        if pdfmetrics.stringWidth(trial, font, size) <= width:
            line = trial
            continue
        if line:
            lines.append(line)
        if pdfmetrics.stringWidth(word, font, size) <= width:
            line = word
            continue
        # Split an oversized token.
        buf = ""
        for ch in word:
            t = buf + ch
            if pdfmetrics.stringWidth(t, font, size) <= width:
                buf = t
            else:
                if buf:
                    lines.append(buf)
                buf = ch
        line = buf
    if line:
        lines.append(line)
    return lines or [""]


def draw_wrapped(c: canvas.Canvas, text: str, x: float, y: float, width: float,
                 font: str, size: float, leading: float, min_y: float) -> float:
    """Draw wrapped text downward. Returns y of the next baseline (below last line)."""
    lines = wrap_lines(text, font, size, width)
    c.setFont(font, size)
    c.setFillColor(black)
    for i, line in enumerate(lines):
        baseline = y - i * leading
        if baseline < min_y:
            record(f"Text would go below min_y={min_y:.1f}: {text[:48]!r}")
            break
        c.drawString(x, baseline, line)
    return y - len(lines) * leading


def assert_in_page(x0: float, y0: float, x1: float, y1: float, label: str) -> None:
    if x0 < SAFE or y0 < SAFE or x1 > PAGE_W - SAFE or y1 > PAGE_H - SAFE:
        record(f"{label} outside safe box: ({x0:.1f},{y0:.1f})-({x1:.1f},{y1:.1f})")


def page_border(c: canvas.Canvas) -> None:
    c.setFillColor(white)
    c.setStrokeColor(black)
    c.setLineWidth(3)
    c.rect(MARGIN - 6, MARGIN - 6, PAGE_W - 2 * MARGIN + 12, PAGE_H - 2 * MARGIN + 12, stroke=1, fill=0)
    c.setLineWidth(1.2)
    c.rect(MARGIN - 2, MARGIN - 2, PAGE_W - 2 * MARGIN + 4, PAGE_H - 2 * MARGIN + 4, stroke=1, fill=0)
    assert_in_page(MARGIN - 6, MARGIN - 6, PAGE_W - (MARGIN - 6), PAGE_H - (MARGIN - 6), "page border")


def footer(c: canvas.Canvas, page: int, total: int, note: str) -> None:
    c.setFillColor(black)
    c.setFont("Sans", 8.5)
    # Sit inside the double border, not in the physical margin.
    y = MARGIN + 8
    if y < SAFE + 4:
        record("footer too low")
    c.drawString(MARGIN + 8, y, note)
    c.setFont("Sans-Bold", 8.5)
    label = f"{page} / {total}"
    c.drawRightString(PAGE_W - MARGIN - 8, y, label)


def scissors_mark(c: canvas.Canvas, x: float, y: float, horizontal: bool) -> None:
    """Tiny cut cue: a simple open 'V' like scissors tips, line art only."""
    c.setStrokeColor(black)
    c.setLineWidth(1.2)
    c.setLineCap(1)
    if horizontal:
        c.line(x - 5, y + 3, x, y)
        c.line(x - 5, y - 3, x, y)
    else:
        c.line(x - 3, y + 5, x, y)
        c.line(x + 3, y + 5, x, y)


def dashed_cut(c: canvas.Canvas, x1: float, y1: float, x2: float, y2: float) -> None:
    c.setStrokeColor(black)
    c.setDash(5, 4)
    c.setLineWidth(1.2)
    c.line(x1, y1, x2, y2)
    c.setDash()


# --- simple geometric decorations (no pictures of animals) ---

def icon_eye(c: canvas.Canvas, cx: float, cy: float, s: float) -> None:
    c.setStrokeColor(black)
    c.setFillColor(white)
    c.setLineWidth(1.8)
    p = c.beginPath()
    p.moveTo(cx - s, cy)
    p.curveTo(cx - s * 0.5, cy + s * 0.7, cx + s * 0.5, cy + s * 0.7, cx + s, cy)
    p.curveTo(cx + s * 0.5, cy - s * 0.7, cx - s * 0.5, cy - s * 0.7, cx - s, cy)
    c.drawPath(p, stroke=1, fill=0)
    c.circle(cx, cy, s * 0.32, stroke=1, fill=0)
    c.setFillColor(black)
    c.circle(cx, cy, s * 0.12, stroke=0, fill=1)


def icon_ear(c: canvas.Canvas, cx: float, cy: float, s: float) -> None:
    c.setStrokeColor(black)
    c.setFillColor(white)
    c.setLineWidth(1.8)
    p = c.beginPath()
    p.moveTo(cx - s * 0.15, cy + s)
    p.curveTo(cx + s * 1.1, cy + s * 0.7, cx + s * 1.1, cy - s * 0.7, cx - s * 0.15, cy - s)
    c.drawPath(p, stroke=1, fill=0)
    p = c.beginPath()
    p.moveTo(cx - s * 0.15, cy + s * 0.55)
    p.curveTo(cx + s * 0.55, cy + s * 0.4, cx + s * 0.55, cy - s * 0.4, cx - s * 0.15, cy - s * 0.55)
    c.drawPath(p, stroke=1, fill=0)


def icon_bolt(c: canvas.Canvas, cx: float, cy: float, s: float) -> None:
    c.setStrokeColor(black)
    c.setFillColor(white)
    c.setLineWidth(1.8)
    p = c.beginPath()
    p.moveTo(cx + s * 0.15, cy + s)
    p.lineTo(cx - s * 0.45, cy + 0.05)
    p.lineTo(cx + 0.02, cy + 0.05)
    p.lineTo(cx - s * 0.15, cy - s)
    p.lineTo(cx + s * 0.45, cy - 0.05)
    p.lineTo(cx - 0.02, cy - 0.05)
    p.close()
    c.drawPath(p, stroke=1, fill=0)


def icon_waves(c: canvas.Canvas, cx: float, cy: float, s: float) -> None:
    c.setStrokeColor(black)
    c.setLineWidth(1.8)
    c.setLineCap(1)
    for i, r in enumerate((s * 0.45, s * 0.75, s * 1.05)):
        p = c.beginPath()
        p.moveTo(cx - r * 0.15, cy - r)
        p.curveTo(cx - r, cy - r * 0.3, cx - r, cy + r * 0.3, cx - r * 0.15, cy + r)
        c.drawPath(p, stroke=1, fill=0)


def draw_cover_icons(c: canvas.Canvas, y: float) -> None:
    xs = [PAGE_W / 2 - 105, PAGE_W / 2 - 35, PAGE_W / 2 + 35, PAGE_W / 2 + 105]
    fns = (icon_eye, icon_ear, icon_bolt, icon_waves)
    labels = ("See", "Hear", "Electric", "Far sounds")
    for x, fn, lab in zip(xs, fns, labels):
        c.setStrokeColor(black)
        c.setLineWidth(1.8)
        c.circle(x, y, 24, stroke=1, fill=0)
        fn(c, x, y, 12)
        c.setFillColor(black)
        c.setFont("Sans", 8)
        c.drawCentredString(x, y - 38, lab)


def build_cover(c: canvas.Canvas, data: dict, page: int, total: int) -> None:
    page_border(c)
    inner_l = MARGIN + 10
    inner_r = PAGE_W - MARGIN - 10
    inner_w = inner_r - inner_l
    top = PAGE_H - MARGIN - 16

    # Title block: outlined, not a huge black fill (thermal-friendly).
    title_h = 96
    c.setLineWidth(2.4)
    c.setStrokeColor(black)
    c.setFillColor(white)
    c.rect(inner_l, top - title_h, inner_w, title_h, stroke=1, fill=1)
    # Two thick accent bars, modest area.
    c.setFillColor(black)
    c.rect(inner_l, top - 8, inner_w, 8, stroke=0, fill=1)
    c.rect(inner_l, top - title_h, inner_w, 8, stroke=0, fill=1)

    c.setFillColor(black)
    c.setFont("Sans-Bold", 26)
    c.drawCentredString(PAGE_W / 2, top - 44, data["title"].upper())
    c.setFont("Sans", 13)
    c.drawCentredString(PAGE_W / 2, top - 66, data["subtitle"])
    c.setFont("Sans", 10)
    c.drawCentredString(PAGE_W / 2, top - 84, data["tagline"])

    y = top - title_h - 28
    draw_cover_icons(c, y)
    y -= 58

    c.setFont("Sans-Bold", 16)
    c.drawString(inner_l, y, "How to play")
    y -= 8
    c.setLineWidth(2)
    c.line(inner_l, y, inner_r, y)
    y -= 22

    steps = [
        "Cut out the 12 clue cards along the dashed lines. Keep this front page and the answer page for the reader. Do not cut up the answer page.",
        "Shuffle the cards. One person is the reader. Everyone else guesses.",
        "The reader picks a card and reads Clue 1 aloud. Anyone may guess. If nobody is right, read Clue 2, then Clue 3.",
        "Scoring (optional): a correct guess after Clue 1 is worth 3 points, after Clue 2 is worth 2 points, and after Clue 3 is worth 1 point. Then move to the next card.",
        "Wrong guesses are fine. Just keep going, or agree that a wrong guess means you wait until the next clue.",
        "After all 12 cards, the highest score wins. Or skip the points and play just for fun.",
        "Talk about the sense: how is it like a human sense? How is it different? The answer page has a short, checked fact for each card.",
        "Solo play: read the clues, write your guess, then check the answer page.",
    ]
    for i, step in enumerate(steps, 1):
        # Number in an outlined circle, not a big black disc.
        cx, cy = inner_l + 11, y + 3
        c.setStrokeColor(black)
        c.setFillColor(white)
        c.setLineWidth(1.8)
        c.circle(cx, cy, 10, stroke=1, fill=1)
        c.setFillColor(black)
        c.setFont("Sans-Bold", 11)
        c.drawCentredString(cx, cy - 3.5, str(i))
        y = draw_wrapped(
            c, step, inner_l + 28, y, inner_w - 28,
            "Sans", 10.5, 14, MARGIN + 70,
        )
        y -= 8

    y -= 4
    c.setLineWidth(2.2)
    c.setStrokeColor(black)
    c.setFillColor(white)
    box_top = y + 14
    # Measure box height from remaining text.
    extra = [
        ("Who is it for?", data["ages"]),
        ("Printing tip", "Print at actual size (100%) on A4, black only. Strong black lines, no grey. Best on a Phomemo or Itari M08F thermal printer, or any mono laser / inkjet. Leave the margins as they are."),
        ("A note on the science", "Clues use well-established findings from museums, wildlife services, and universities. A few popular “super sense” claims are left out when the evidence is still unsettled. Sources are listed in the README."),
    ]
    # Estimate height
    box_h = 16
    for head, body in extra:
        box_h += 14 + 14 * max(1, len(wrap_lines(body, "Sans", 10, inner_w - 24)))
        box_h += 8
    box_bottom = box_top - box_h
    if box_bottom < MARGIN + 16:
        record(f"cover note box too low: {box_bottom:.1f}")
        box_bottom = MARGIN + 24
    c.rect(inner_l, box_bottom, inner_w, box_top - box_bottom, stroke=1, fill=0)
    ty = box_top - 16
    for head, body in extra:
        c.setFont("Sans-Bold", 10.5)
        c.setFillColor(black)
        c.drawString(inner_l + 10, ty, head)
        ty -= 14
        ty = draw_wrapped(c, body, inner_l + 10, ty, inner_w - 20, "Sans", 10, 13, box_bottom + 8)
        ty -= 8

    footer(c, page, total, "Animal Super Senses  ·  Clue cards for class or family play")


def card_grid(c: canvas.Canvas) -> tuple[list[tuple[float, float, float, float]], float, float]:
    """Return 2x2 card boxes (x, y, w, h) plus gutter sizes."""
    header_h = 22
    left = MARGIN + 4
    right = PAGE_W - MARGIN - 4
    top = PAGE_H - MARGIN - 8 - header_h
    bottom = MARGIN + 24
    gutter = 10
    grid_w = right - left
    grid_h = top - bottom
    cw = (grid_w - gutter) / 2
    ch = (grid_h - gutter) / 2
    boxes = [
        (left, top - ch, cw, ch),             # top-left
        (left + cw + gutter, top - ch, cw, ch),  # top-right
        (left, bottom, cw, ch),               # bottom-left
        (left + cw + gutter, bottom, cw, ch), # bottom-right
    ]
    return boxes, gutter, top + header_h


def draw_card(c: canvas.Canvas, box: tuple[float, float, float, float], card: dict) -> None:
    x, y, w, h = box
    assert_in_page(x, y, x + w, y + h, f"card {card['id']}")
    c.setStrokeColor(black)
    c.setFillColor(white)
    c.setLineWidth(2.4)
    c.roundRect(x, y, w, h, 6, stroke=1, fill=1)
    c.setLineWidth(1.1)
    c.roundRect(x + 4, y + 4, w - 8, h - 8, 4, stroke=1, fill=0)

    pad = 14
    tx = x + pad
    tw = w - 2 * pad
    top = y + h - pad

    # Number badge (outlined).
    cx, cy = tx + 12, top - 12
    c.setLineWidth(2)
    c.circle(cx, cy, 13, stroke=1, fill=0)
    c.setFillColor(black)
    c.setFont("Sans-Bold", 13)
    c.drawCentredString(cx, cy - 4.5, str(card["id"]))

    c.setFont("Sans-Bold", 12)
    c.drawString(tx + 32, top - 10, "CLUE CARD")
    c.setFont("Sans", 9)
    c.drawString(tx + 32, top - 22, "Read one clue at a time.")
    c.setLineWidth(1.6)
    c.line(tx, top - 28, tx + tw, top - 28)

    cy_text = top - 48
    min_y = y + 36
    for i, clue in enumerate(card["clues"], 1):
        label = f"Clue {i}"
        c.setFont("Sans-Bold", 12)
        c.setFillColor(black)
        c.drawString(tx, cy_text, label)
        cy_text -= 15
        cy_text = draw_wrapped(c, clue, tx, cy_text, tw, "Sans", 12, 16, min_y)
        cy_text -= 10
        if cy_text < min_y:
            record(f"card {card['id']} clues overflow")
            break

    # Prompt at the bottom of the card, always visible.
    prompt_y = y + 16
    c.setLineWidth(1.6)
    c.line(tx, prompt_y + 16, tx + tw, prompt_y + 16)
    c.setFont("Sans-Bold", 12)
    c.setFillColor(black)
    c.drawCentredString(x + w / 2, prompt_y, "What animal am I?")
    if cy_text < prompt_y + 20:
        record(f"card {card['id']} clues collided with prompt (cy={cy_text:.1f})")


def build_card_page(c: canvas.Canvas, cards: list[dict], page: int, total: int) -> None:
    page_border(c)
    boxes, gutter, header_top = card_grid(c)
    c.setFillColor(black)
    c.setFont("Sans-Bold", 11)
    c.drawString(MARGIN + 4, PAGE_H - MARGIN - 16, "ANIMAL SUPER SENSES")
    c.setFont("Sans", 10)
    c.drawRightString(PAGE_W - MARGIN - 4, PAGE_H - MARGIN - 16, "Clue cards  ·  cut on the dashed lines")

    # Cut guides between the four cards.
    left = MARGIN + 4
    right = PAGE_W - MARGIN - 4
    # Use first box to find mid lines
    x, y, w, h = boxes[0]
    # Vertical gutter centre
    vx = boxes[0][0] + boxes[0][2] + gutter / 2
    # Horizontal gutter centre
    hy = boxes[0][1] - gutter / 2
    top = boxes[0][1] + boxes[0][3]
    bottom = boxes[2][1]
    dashed_cut(c, vx, bottom, vx, top)
    dashed_cut(c, left, hy, right, hy)
    scissors_mark(c, vx, top + 2, horizontal=False)
    scissors_mark(c, left - 2, hy, horizontal=True)

    for box, card in zip(boxes, cards):
        draw_card(c, box, card)

    footer(c, page, total, "Keep the answer page uncut  ·  Print A4 at 100%")


def build_answers(c: canvas.Canvas, cards: list[dict], page: int, total: int) -> None:
    page_border(c)
    inner_l = MARGIN + 8
    inner_r = PAGE_W - MARGIN - 8
    inner_w = inner_r - inner_l
    top = PAGE_H - MARGIN - 16

    c.setFillColor(black)
    c.setFont("Sans-Bold", 20)
    c.drawCentredString(PAGE_W / 2, top - 6, "ANSWER PAGE")
    c.setFont("Sans-Bold", 11)
    c.drawCentredString(PAGE_W / 2, top - 24, "Keep this page uncut  ·  For the reader or teacher")
    c.setLineWidth(2)
    c.line(inner_l, top - 30, inner_r, top - 30)

    # Two columns of six.
    gutter = 12
    col_w = (inner_w - gutter) / 2
    col_x = [inner_l, inner_l + col_w + gutter]
    area_top = top - 40
    area_bot = MARGIN + 28
    row_h = (area_top - area_bot) / 6

    for i, card in enumerate(cards):
        col = i // 6
        row = i % 6
        x = col_x[col]
        yb = area_top - (row + 1) * row_h
        yt = yb + row_h
        # Modest inset so boxes don't collide.
        pad_box = 3
        bx, by, bw, bh = x, yb + pad_box, col_w, row_h - 2 * pad_box
        c.setStrokeColor(black)
        c.setFillColor(white)
        c.setLineWidth(1.8)
        c.roundRect(bx, by, bw, bh, 4, stroke=1, fill=0)

        # Number badge
        cx, cy = bx + 16, by + bh - 16
        c.setLineWidth(1.6)
        c.circle(cx, cy, 10, stroke=1, fill=0)
        c.setFillColor(black)
        c.setFont("Sans-Bold", 10)
        c.drawCentredString(cx, cy - 3.5, str(card["id"]))

        c.setFont("Sans-Bold", 11)
        title = f"{card['answer']}  —  {card['sense']}"
        # Shrink slightly if needed
        size = 11
        title_x = bx + 30
        title_w = bw - 38
        while size > 8 and pdfmetrics.stringWidth(title, "Sans-Bold", size) > title_w:
            size -= 0.5
        c.setFont("Sans-Bold", size)
        c.drawString(title_x, by + bh - 20, title)

        c.setFont("Sans-Italic", 8.5)
        c.drawString(title_x, by + bh - 32, card["sense_plain"])

        body_top = by + bh - 46
        min_y = by + 8
        y = draw_wrapped(c, card["fact"], bx + 10, body_top, bw - 20, "Sans", 8.5, 11, min_y)
        if y < min_y:
            record(f"answer {card['id']} overflow")

        assert_in_page(bx, by, bx + bw, by + bh, f"answer box {card['id']}")

    footer(c, page, total, "Accept close answers as noted in the README  ·  Facts checked 11 Nov 2026")


def build() -> Path:
    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    cards = data["cards"]
    if len(cards) != 12:
        raise SystemExit(f"Expected 12 cards, got {len(cards)}")

    total = 5  # cover + 3 card pages + answers
    c = canvas.Canvas(str(OUT_PDF), pagesize=A4)
    c.setTitle("Animal Super Senses — a science guessing game")
    c.setAuthor("Classroom printable")
    c.setSubject("A4 black-and-white clue-card game about animal senses")

    build_cover(c, data, 1, total)
    c.showPage()
    for p, chunk in enumerate((cards[0:4], cards[4:8], cards[8:12]), start=2):
        build_card_page(c, chunk, p, total)
        c.showPage()
    build_answers(c, cards, 5, total)
    c.save()
    return OUT_PDF


if __name__ == "__main__":
    path = build()
    print(f"Wrote {path}")
    if ISSUES:
        print(f"{len(ISSUES)} layout issue(s):")
        for msg in ISSUES:
            print(" -", msg)
        sys.exit(1)

# Script 12: "Living Battery"
**Format:** 70–80s short (narration, ~80s). **Topic:** animal kingdom

**Title:** The Electric Eel Isn't an Eel (It's a Living Battery)
**Caption:** A South American knifefish can make hundreds of volts with stacked living "batteries." A higher voltage than a wall socket does not automatically mean a more dangerous shock. #animals #nature #science #matsapphouse

## Hook
"This fish has been measured at 860 volts, and it isn't even an eel."

## Narration + visual cues

| Time | Narration | Visual cue |
|---|---|---|
| 0:00 | This fish has been measured at 860 volts, and it isn't even an eel. | Dark river; a long olive-grey fish glides past; a crackle of light outlines its body. |
| 0:06 | It lives in the rivers of South America. Despite the name, it's a knifefish, more closely related to catfish than to true eels. | Map of the Amazon basin; family-tree card: "knifefish, related to catfish — not true eels." |
| 0:15 | Most of its body is packed with electric organs: thousands of cells called electrocytes, stacked like batteries in a torch so their tiny voltages add up. | Cutaway: pink-green rows of disc-shaped cells light up; a voltage counter ticks upward. |
| 0:25 | In 2019, scientists described Electrophorus voltai and measured 860 volts — the strongest shock known from any animal, and several times the voltage of a typical wall socket. | Card: "Electrophorus voltai · 860 V · de Santana et al., 2019". |
| 0:36 | But voltage isn't the same as danger. A wall socket can keep pushing a strong current for a long time. An eel's zap is a very short pulse. It can still hurt and make muscles seize up, so treat both with respect. | Simple graphic: "voltage" versus "current and time"; a brief pulse beside a continuous outlet current. |
| 0:49 | Quick shocks can make hidden prey twitch, giving away exactly where it's hiding. | A small fish hidden under leaves twitches; the eel turns and strikes. |
| 0:57 | And when threatened, an eel can leap from the water and press its chin against the attacker, sending the shock straight in. Alexander von Humboldt described this over 200 years ago; a scientist filmed it in 2016. | Illustrated recreation of a leaping eel (not a historic engraving unless public domain), then a modern lab-style shot. |
| 1:11 | A fish, a battery, and a high jumper. Nature got there first. | The eel glides away into the dark. End card: matsapphouse logo. |

*Approx. 185 words of narration, ~80 seconds at a relaxed pace.*

## Production notes
- Do not use the old Humboldt engraving unless it is confirmed public domain; an illustrated recreation is safer.
- If generating footage, keep eel anatomy plausible: no pelvic fins, and a long anal fin along the belly that it uses to swim.
- Do not say the eel "out-zaps" or is "more dangerous than" a wall socket. Voltage can be higher; danger also depends on current and how long it lasts.
- Do not encourage touching eels or anything in a wall socket.

## Source notes
- Electric eels (*Electrophorus*) are South American knifefishes (Gymnotiformes), more closely related to catfishes than to true eels (Anguilliformes). Standard taxonomy.
- Electrocytes in the electric organs are stacked in series so their voltages add up. Textbook physiology.
- Three living species are recognised. One specimen of *Electrophorus voltai* produced a high-voltage discharge of 860 V, the strongest known from a living animal: de Santana, C. D. et al., *Nature Communications* 10:4000 (2019). https://doi.org/10.1038/s41467-019-11690-z (open access). The 860 V figure is a measured discharge from one fish (1219 mm long), not an average for every eel.
- A typical household socket is about 100–240 volts depending on the country, so 860 V is several times higher. That is not the same as being more dangerous. Shock risk depends on current and how long it flows. The 2019 paper reports voltage, not a simple "more dangerous than a wall socket" result. Popular interviews with the authors describe the eel's pulse as brief, and household supply as able to deliver a stronger, longer-lasting current. The narration stays qualitative on that point and does not use unverified ampere figures.
- High-voltage pulses can make hidden prey twitch, revealing their location: Catania, K. C., "The shocking predatory strike of the electric eel", *Science* 346:1231–1234 (2014). https://doi.org/10.1126/science.1260807
- Leaping attack on threats, supporting Humboldt's 1800 account: Catania, K. C., *Proceedings of the National Academy of Sciences* 113:6979–6984 (2016). https://doi.org/10.1073/pnas.1604009113

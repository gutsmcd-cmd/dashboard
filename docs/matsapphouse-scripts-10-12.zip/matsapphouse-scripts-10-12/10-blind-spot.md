# Script 10: "The Hole in Your Vision"
**Format:** 70–80s short (narration, ~75s). **Topic:** neuroscience

**Title:** There's a Hole in Your Vision Right Now (and Your Brain Hides It)
**Caption:** Each of your eyes has a blind spot where there are zero light sensors, and your brain quietly paints over it. Try the test at 0:40. #neuroscience #brain #science #matsapphouse

## Hook
"Right now, there's a hole in what you're seeing, and your brain is covering it up."

## Narration + visual cues

| Time | Narration | Visual cue |
|---|---|---|
| 0:00 | Right now, there's a hole in what you're seeing, and your brain is covering it up. | Extreme close-up of an eye; a black circle "punches" through the frame, then smoothly heals over. |
| 0:06 | At the back of each eye is the retina, a thin sheet packed with light-sensing cells called rods and cones. | Animated cutaway of the eyeball; retina glows pink-green, rods and cones twinkle. |
| 0:14 | But all the nerve fibres from those cells have to leave the eye somewhere. They bundle together into the optic nerve and exit through one spot: the optic disc. | Fibres converge like streams into a river and pour out the back of the eye. |
| 0:24 | At that spot there are no rods and no cones at all. Zero. So any light that lands there is simply not detected. That's your blind spot, and you have one in each eye. | The optic disc highlighted; light rays hit it and vanish with a soft "blip". |
| 0:36 | Want to find yours? Close your left eye. Stare at the cross with your right eye, and slowly move closer to the screen. | Full-screen test card: a black + on the left, a big pink dot on the right, white background. On-screen text: "Close LEFT eye. Look at the +. Move closer slowly." Hold 8s. |
| 0:46 | At one distance, the dot just... vanishes. | Hold the card; nothing changes on screen (the effect happens in the viewer's eye). |
| 0:50 | Here's the wild part: you don't see a black hole there. Your brain fills the gap using the surrounding colours and patterns. | Swap card: dot sitting on green stripes. Text: "Try again: the stripes look unbroken." |
| 1:00 | Normally you never notice, because your two eyes cover each other's blind spots, and your brain stitches it all together. | Two overlapping vision cones; each blind spot covered by the other eye's view. |
| 1:08 | So what you "see" isn't a live camera feed. It's your brain's best guess. | Presenter taps their temple, grinning. End card: matsapphouse logo. |

*Approx. 185 words of narration, ~75 seconds at a relaxed pace.*

## Production notes
- The test card must be simple and high-contrast; put the + and the dot roughly 8–10 cm apart on a phone-sized frame (viewers will adjust distance).
- Say "close your LEFT eye, look at the cross" exactly; if the dot is on the right, the right eye is the one being tested.
- Keep the test card on screen long enough to try (at least 8 seconds).

## Source notes
- The optic disc, where the optic nerve leaves the eye, has no photoreceptors, so each eye has a blind spot. This is standard textbook anatomy, first described by Edme Mariotte in the 1660s.
- The brain fills in the blind spot with surrounding colour and pattern (perceptual filling-in): V. S. Ramachandran, "Blind Spots", *Scientific American* 266(5):86–94 (1992). https://doi.org/10.1038/scientificamerican0592-86
- With both eyes open, each eye's blind spot falls on a region the other eye can see, so it usually goes unnoticed.

# Script 11: "Why Your Recorded Voice Sounds Wrong"
**Format:** 70–80s short (narration, ~75s). **Topic:** science (physics of sound / hearing)

**Title:** Why Your Voice Sounds So Weird on Recordings
**Caption:** That odd feeling when you hear your own voice played back? It's physics, not a broken microphone. Part of what you normally hear travels through your skull. #science #sound #physics #matsapphouse

## Hook
"Ever heard yourself on a recording and thought, 'That is not what I sound like'? You're right, and also wrong."

## Narration + visual cues

| Time | Narration | Visual cue |
|---|---|---|
| 0:00 | Ever heard yourself on a recording and thought, "That is not what I sound like"? You're right... and also wrong. | Presenter plays a voice memo on a phone and looks surprised. |
| 0:07 | When other people hear you, your voice travels one way: through the air, into their ears. | Pink sound waves ripple from the mouth across the room into a listener's ear. |
| 0:14 | But when you hear yourself, the sound takes two routes. Some goes through the air, around to your ears. | The same pink waves curl around to the speaker's own ear. |
| 0:21 | And some travels straight through your body: from your vocal cords, through the bones of your skull, right to your inner ear. That's called bone conduction. | X-ray style animation: green waves travel through the skull bone directly to the spiral cochlea. |
| 0:32 | Your skull and tissues pass on the low, deep sounds especially well, so the voice inside your head sounds richer and lower than the one everyone else hears. | Graphic equaliser: the "inside your head" bars are boosted on the bass side. |
| 0:43 | A microphone only catches the air version — not the bone-conduction path. That's why a recording can sound thinner or higher than the voice you expect. | Microphone icon catches only the pink waves; green waves fade out. |
| 0:54 | Here's the surprising part: that air-only version is much closer to how you already sound to everyone else. | Split screen: "you, from the inside" versus "everyone else / the recording". |
| 1:03 | So the voice that startles you on a recording is often just one you've rarely heard from the outside — the one your friends already know. | Presenter plays the memo again, smiles, shrugs. End card: matsapphouse logo. |

*Approx. 180 words of narration, ~75 seconds at a relaxed pace.*

## Production notes
- Easy home demo for B-roll: plug your ears with your fingers and hum. It sounds louder and deeper (the occlusion effect, from bone-conducted sound being trapped). Optional; keep it as a visual only if time runs short.
- Do not say that "studies prove everyone hates their voice", or that people usually fail to recognise themselves and rate the recording more harshly. Those precise claims were not kept (see source notes).

## Source notes
- When you speak, you hear your voice both by air conduction and by bone conduction through the skull to the cochlea: Georg von Békésy, "The Structure of the Middle Ear and the Hearing of One's Own Voice by Bone Conduction", *Journal of the Acoustical Society of America* 21:217–232 (1949). https://doi.org/10.1121/1.1906501
- Bone conduction emphasises lower frequencies, so your own voice sounds fuller and lower to you than the air-only version other people hear. Recordings capture only the air-conducted sound. This is well established in audiology.
- A draft line citing Holzman and Rousey (1966), "The voice as a percept", *Journal of Personality and Social Psychology* 4(1):79–86, https://doi.org/10.1037/h0023518, said people "often didn't recognise their own" voice and "rated their own voice more harshly." The full paper is behind a paywall and was not available to check wording. The official abstract reports affective disturbance, a mismatch with how people expected to sound, and defensive negation — not a simple recognition-failure or harsher-rating result. A 1967 follow-up paper is the one later popular accounts cite for recognition rates, and later work is mixed (for example, people may rate an unrecognised recording of themselves as more attractive: Hughes and Harrison, 2013). Because the precise study summary could not be verified, it was removed from the narration. The script now stays with the established physics.

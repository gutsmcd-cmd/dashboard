import random, math, re, cairosvg
from PIL import Image, ImageDraw, ImageFilter, ImageChops
K='/workspace/theme-kit/'
def hx(h):h=h.lstrip('#');return tuple(int(h[i:i+2],16) for i in (0,2,4))
def grad(w,h,c1,c2):
    a=Image.new('RGB',(1,256));[a.putpixel((0,i),tuple(int(c1[k]+(c2[k]-c1[k])*i/255) for k in range(3))) for i in range(256)]
    return a.resize((w,h),Image.BICUBIC)
def glow(img,blobs,blur):
    w,h=img.size; L=Image.new('RGB',(w,h),(0,0,0)); d=ImageDraw.Draw(L)
    for x,y,r,c in blobs: d.ellipse([x*w-r*w,y*h-r*w,x*w+r*w,y*h+r*w],fill=hx(c))
    L=L.filter(ImageFilter.GaussianBlur(blur*w/1080))
    return ImageChops.screen(img,L)
def grain(img,amt=6):
    n=Image.effect_noise(img.size,amt*4).convert('RGB')
    return Image.blend(img,ImageChops.overlay(img,n),0.08)
def stars(img,n,seed):
    r=random.Random(seed);d=ImageDraw.Draw(img);w,h=img.size
    for _ in range(n):
        x,y=r.random()*w,r.random()*h*.7;s=r.choice([1,1,1.5,2,3])*w/1080
        d.ellipse([x-s,y-s,x+s,y+s],fill=(255,240,245))
    return img
def hills(img,cols,seed,amp=.06):
    w,h=img.size;r=random.Random(seed)
    for i,c in enumerate(cols):
        base=h*(.72+i*.08);ph=r.random()*6;f=r.uniform(1.2,2.4)
        pts=[(x,base+amp*h*math.sin(x/w*f*math.pi+ph)) for x in range(0,w+20,20)]+[(w,h),(0,h)]
        m=Image.new('L',(w,h));ImageDraw.Draw(m).polygon(pts,fill=255);m=m.filter(ImageFilter.GaussianBlur(2))
        img.paste(Image.new('RGB',(w,h),hx(c)),(0,0),m)
    return img
def sakura(img,seed,n=40):
    w,h=img.size;r=random.Random(seed);L=Image.new('RGBA',(w,h))
    for _ in range(n):
        s=r.uniform(10,30)*w/1080;x,y=r.random()*w,r.random()*h;p=Image.new('RGBA',(int(s*3),int(s*3)))
        ImageDraw.Draw(p).ellipse([s*.5,s,s*2.5,s*2],fill=hx(r.choice(['#FBD3E0','#F06292','#FFF8F3']))+(r.randint(150,230),))
        p=p.rotate(r.random()*360,expand=1);L.alpha_composite(p,(int(x),int(y)))
    return Image.alpha_composite(img.convert('RGBA'),L.filter(ImageFilter.GaussianBlur(1))).convert('RGB')
def make(name,W,H):
    if name=='dawn':
        im=grad(W,H,hx('#FBD3E0'),hx('#C8F2DA'))
        im=glow(im,[(.75,.22,.35,'#F06292'),(.2,.55,.4,'#8FBF9F'),(.5,.9,.45,'#2E9E6A')],160)
        im=hills(im,['#8FBF9F','#2E9E6A'],1,.04)
    elif name=='night':
        im=grad(W,H,hx('#0E2A22'),hx('#3A0F24'))
        im=glow(im,[(.25,.25,.35,'#8E1B4C'),(.8,.6,.4,'#1B4D3E'),(.6,.15,.12,'#D81B60')],200)
        im=stars(im,260 if H>W else 200,2)
        im=glow(im,[(.72,.18,.05,'#FFF8F3')],40)
        im=hills(im,['#1B4D3E','#0E2A22'],2,.04)
    elif name=='matcha':
        im=grad(W,H,hx('#C8F2DA'),hx('#8FBF9F'))
        im=glow(im,[(.3,.3,.3,'#FFF8F3'),(.8,.7,.35,'#F06292'),(.15,.85,.3,'#2E9E6A')],220)
    elif name=='sakura':
        im=grad(W,H,hx('#FFF8F3'),hx('#FBD3E0'))
        im=glow(im,[(.7,.3,.35,'#F06292'),(.2,.75,.35,'#8FBF9F')],200)
        im=sakura(im,3,60 if H>W else 50)
    elif name=='aurora':
        im=grad(W,H,hx('#081C17'),hx('#1B0A14'))
        for i in range(5):
            im=glow(im,[(.15+i*.18,.25+.08*math.sin(i*1.3),.16,['#2E9E6A','#8FBF9F','#D81B60','#2E9E6A','#F06292'][i])],140)
        im=stars(im,150,4)
    else: # bloom
        im=grad(W,H,hx('#8E1B4C'),hx('#1B4D3E'))
        im=glow(im,[(.5,.45,.3,'#F06292'),(.5,.45,.12,'#FBD3E0'),(.1,.9,.3,'#2E9E6A'),(.9,.1,.25,'#C8F2DA')],180)
    return grain(im)
for n in ['dawn','night','matcha','sakura','aurora','bloom']:
    make(n,1080,2400).save(K+f'wallpapers/phone/pixel6-{n}-1080x2400.png',optimize=True)
    make(n,1920,1080).save(K+f'wallpapers/desktop/desktop-{n}-1920x1080.png',optimize=True)
# remove stale flat svgs for re-rendered ones
import os
for p in ['wallpapers/phone/pixel6-dawn-1080x2400.svg','wallpapers/phone/pixel6-night-1080x2400.svg','wallpapers/desktop/desktop-dawn-1920x1080.svg','wallpapers/desktop/desktop-night-1920x1080.svg']:
    if os.path.exists(K+p): os.rename(K+p,K+p.replace('.svg','.flat-old.svg'))
# icons
P=[('#F06292','#FFF8F3','#2E9E6A'),('#2E9E6A','#FFF8F3','#F06292'),('#FBD3E0','#1B4D3E','#D81B60'),('#C8F2DA','#8E1B4C','#2E9E6A')]
G={
'notes':'<rect x="34" y="26" width="60" height="76" rx="8" fill="{g}"/><path d="M46 48h36M46 62h36M46 76h22" stroke="{b}" stroke-width="6" stroke-linecap="round"/><circle cx="86" cy="84" r="9" fill="{a}"/>',
'films':'<rect x="26" y="36" width="76" height="56" rx="8" fill="{g}"/><g fill="{b}"><rect x="32" y="42" width="8" height="8" rx="2"/><rect x="32" y="60" width="8" height="8" rx="2"/><rect x="32" y="78" width="8" height="8" rx="2"/><rect x="88" y="42" width="8" height="8" rx="2"/><rect x="88" y="60" width="8" height="8" rx="2"/><rect x="88" y="78" width="8" height="8" rx="2"/></g><path d="M56 52v24l20-12z" fill="{a}"/>',
'games':'<path d="M40 44h48a16 16 0 0 1 16 16l2 18a10 10 0 0 1-18 6l-6-8H46l-6 8a10 10 0 0 1-18-6l2-18a16 16 0 0 1 16-16z" fill="{g}"/><path d="M44 56v14M37 63h14" stroke="{b}" stroke-width="6" stroke-linecap="round"/><circle cx="82" cy="58" r="5" fill="{a}"/><circle cx="90" cy="68" r="5" fill="{b}"/>',
'pets':'<ellipse cx="64" cy="72" rx="28" ry="24" fill="{g}"/><path d="M40 60l-6-26 20 14zM88 60l6-26-20 14z" fill="{g}"/><circle cx="54" cy="68" r="4" fill="{b}"/><circle cx="74" cy="68" r="4" fill="{b}"/><ellipse cx="64" cy="80" rx="6" ry="4" fill="{a}"/>',
'translate':'<rect x="24" y="28" width="48" height="40" rx="8" fill="{g}"/><text x="48" y="58" font-family="sans-serif" font-weight="700" font-size="26" text-anchor="middle" fill="{b}">A</text><rect x="56" y="58" width="48" height="40" rx="8" fill="{a}"/><text x="80" y="88" font-family="sans-serif" font-weight="700" font-size="24" text-anchor="middle" fill="{g}">あ</text>',
'weather':'<circle cx="54" cy="52" r="16" fill="{a}"/><path d="M44 92h44a14 14 0 0 0 0-28 20 20 0 0 0-38 4 12 12 0 0 0-6 24z" fill="{g}"/>',
'books':'<rect x="30" y="30" width="16" height="68" rx="3" fill="{g}"/><rect x="50" y="38" width="16" height="60" rx="3" fill="{a}"/><rect x="72" y="32" width="16" height="66" rx="3" fill="{g}" transform="rotate(12 80 98)"/><path d="M26 100h76" stroke="{g}" stroke-width="6" stroke-linecap="round"/>',
'clock':'<circle cx="64" cy="64" r="36" fill="{g}"/><path d="M64 42v24l14 10" stroke="{b}" stroke-width="7" stroke-linecap="round" fill="none"/><circle cx="64" cy="64" r="5" fill="{a}"/>',
}
for i,(n,body) in enumerate(G.items()):
    b,g,a=P[i%4]
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128"><defs><linearGradient id="s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{b}"/><stop offset="1" stop-color="{a}" stop-opacity=".35"/></linearGradient></defs><rect width="128" height="128" rx="30" fill="{b}"/><rect width="128" height="128" rx="30" fill="url(#s)"/>'+body.format(b=b,g=g,a=a)+'</svg>'
    open(K+f'icons/svg/{n}.svg','w').write(svg)
    for s in (192,512): cairosvg.svg2png(bytestring=svg.encode(),write_to=K+f'icons/png/{n}-{s}.png',output_width=s,output_height=s)
# preview
ic=['home','camera','music','mail','leaf','heart','paw','calendar']+list(G)
wp=['dawn','night','waves','petals','matcha','sakura','aurora','bloom']
h=open(K+'preview/index.html').read()
h=re.sub(r'(<h2>Icons</h2><div class="ic">).*?</div>',lambda m:m.group(1)+''.join(f'<img src="../icons/svg/{n}.svg" title="{n}">' for n in ic)+'</div>',h,flags=re.S)
h=re.sub(r'(<h2>Wallpapers</h2><div class="wp">).*?</div>',lambda m:m.group(1)+''.join(f'<img src="../wallpapers/phone/pixel6-{n}-1080x2400.png">' for n in wp)+'</div><div class="wp" style="margin-top:12px">'+''.join(f'<img src="../wallpapers/desktop/desktop-{n}-1920x1080.png">' for n in wp)+'</div>',h,flags=re.S)
open(K+'preview/index.html','w').write(h)

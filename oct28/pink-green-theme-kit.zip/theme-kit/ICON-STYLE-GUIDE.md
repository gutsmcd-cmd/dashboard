# App-Icon Style Guide — Pink & Green

- **Canvas:** 128×128 viewBox, rounded square, corner radius 30 (≈23%). Export PNG at 192 and 512.
- **Safe area:** keep glyphs inside the central 80×80 (24–104).
- **Glyphs:** flat solid shapes, 6–8px strokes with round caps, no outlines on fills.
- **Pairings (background / glyph / accent):**
  1. Rose `#F06292` / Cream `#FFF8F3` / Emerald `#2E9E6A`
  2. Emerald `#2E9E6A` / Cream / Rose
  3. Blush `#FBD3E0` / Forest `#1B4D3E` / Fuchsia `#D81B60`
  4. Mint `#C8F2DA` / Berry `#8E1B4C` / Emerald
- Every background gets a soft diagonal wash of its accent (35% opacity) so pink icons hint green and the reverse.
- Rotate pairings so neighbouring icons alternate pink and green.
- **Samples:** icons/svg/*.svg and icons/png/*-{192,512}.png (home, camera, music, mail, leaf, heart, paw, calendar, notes, films, games, pets, translate, weather, books, clock).
- Contrast: glyph and background pairs are at least 3:1.

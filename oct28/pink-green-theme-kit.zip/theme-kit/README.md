# Pink & Green Theme Kit
- wallpapers/phone — 8 Pixel 6 wallpapers 1080×2400 (PNG; dawn & night now have real blurred glows; waves/petals also SVG)
- wallpapers/desktop — 8 matching desktop wallpapers 1920×1080
- icons/ — 16 sample icons, SVG + PNG 192/512; see ICON-STYLE-GUIDE.md
- css/palette.css — custom properties, light + dark ([data-theme="dark"] or system setting)
- preview/index.html — open in a browser; button toggles light/dark
- tools/build.py — regenerates wallpapers, new icons and preview (Pillow + cairosvg)

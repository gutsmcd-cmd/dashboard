M@ Offline Apps – add-on update (28 Oct 2026)

Unzip this into your phone folder Download/M@ Offline Apps so the new apps/ folders sit next to the old ones.
It replaces checklist.html (your ticks are kept – they live in the browser, not the file).

New: Pet House, Koro Films for Rie, Studio, Family Files.
Open each from checklist.html ("Open offline"), or open apps/<name>/phone.html directly.
The Family Files photo zip (38 MB) is not included; its button opens the live site.
